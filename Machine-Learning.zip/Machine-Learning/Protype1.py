# To support both python 2 and python 3
from __future__ import division, print_function, unicode_literals
import matplotlib.pyplot as plt

# Common imports
import numpy as np
import os

np.random.seed(42)

from sklearn.tree import DecisionTreeClassifier # Import Decision Tree Classifier
from sklearn.model_selection import train_test_split # Import train_test_split function
from sklearn.metrics import mean_squared_error
from sklearn import metrics #Import scikit-learn metrics module for accuracy calculation

import pandas as pd


col_names = ['Concentration', 'Year', 'Semester', 'SLS 1106', 'IDS 1380', 'ENC 1101', 'CHM 2045', 'CHM 2045L', 'MAC 2311', 'EGN 1007C', 'PHY 2048', 'PHY 2048L', 'ENC 2210', 'COP 2271C', 'MAC 2312', 'PHY 2049', 'PHY 2049L', 'COP 3337C', 'MAC 2313', 'AMH 2020', 'IDS 2144', 'MAD 2104', 'MAP 2302', 'EEL 3111C', 'EEL 3702C', 'STA 3032', 'EEL 3112C', 'EEE 3310', 'COP 3530', 'EEL 4746C', 'CNT 3004C', 'MAS 3105', 'EEL 3135', 'EEL 4768C', 'IDS 4941', 'ARH 2000', 'EEE 4510', 'COP 4610', 'EEL 4914C', 'CDA 4210', 'EEE 4351', 'CEN 4010', 'EEL 4915C', 'EEL 4794', 'ENT 2112', 'HUM 2022', 'PHI 2010', 'LIT 2000', 'SLS 1106 P', 'IDS 1380 P', 'ENC 1101 P', 'CHM 2045 P', 'CHM 2045L P', 'MAC 2311 P', 'EGN 1007C P', 'PHY 2048 P', 'PHY 2048L P', 'ENC 2210 P', 'COP 2271C P', 'MAC 2312 P', 'PHY 2049 P', 'PHY 2049L P', 'COP 3337C P', 'MAC 2313 P', 'AMH 2020 P', 'IDS 2144 P', 'MAD 2104 P', 'MAP 2302 P', 'EEL 3111C P', 'EEL 3702C P', 'STA 3032 P', 'EEL 3112C P', 'EEE 3310 P', 'COP 3530 P', 'EEL 4746C P', 'CNT 3004C P', 'MAS 3105 P', 'EEL 3135 P', 'EEL 4768C P', 'IDS 4941 P', 'ARH 2000 P', 'EEE 4510 P', 'COP 4610 P', 'EEL 4914C P', 'CDA 4210 P', 'EEE 4351 P', 'CEN 4010 P', 'EEL 4915C P', 'EEL 4794 P', 'ENT 2112 P', 'HUM 2022 P', 'PHI 2010 P', 'LIT 2000 P']
# load dataset
Classes = pd.read_csv("CEtestData.csv")

feature_cols = ['Concentration', 'Year', 'Semester', 'SLS 1106', 'IDS 1380', 'ENC 1101', 'CHM 2045', 'CHM 2045L', 'MAC 2311', 'EGN 1007C', 'PHY 2048', 'PHY 2048L', 'ENC 2210', 'COP 2271C', 'MAC 2312', 'PHY 2049', 'PHY 2049L', 'COP 3337C', 'MAC 2313', 'AMH 2020', 'IDS 2144', 'MAD 2104', 'MAP 2302', 'EEL 3111C', 'EEL 3702C', 'STA 3032', 'EEL 3112C', 'EEE 3310', 'COP 3530', 'EEL 4746C', 'CNT 3004C', 'MAS 3105', 'EEL 3135', 'EEL 4768C', 'IDS 4941', 'ARH 2000', 'EEE 4510', 'COP 4610', 'EEL 4914C', 'CDA 4210', 'EEE 4351', 'CEN 4010', 'EEL 4915C', 'EEL 4794', 'ENT 2112', 'HUM 2022', 'PHI 2010', 'LIT 2000']
Predict_cols = ['SLS 1106 P', 'IDS 1380 P', 'ENC 1101 P', 'CHM 2045 P', 'CHM 2045L P', 'MAC 2311 P', 'EGN 1007C P', 'PHY 2048 P', 'PHY 2048L P', 'ENC 2210 P', 'COP 2271C P', 'MAC 2312 P', 'PHY 2049 P', 'PHY 2049L P', 'COP 3337C P', 'MAC 2313 P', 'AMH 2020 P', 'IDS 2144 P', 'MAD 2104 P', 'MAP 2302 P', 'EEL 3111C P', 'EEL 3702C P', 'STA 3032 P', 'EEL 3112C P', 'EEE 3310 P', 'COP 3530 P', 'EEL 4746C P', 'CNT 3004C P', 'MAS 3105 P', 'EEL 3135 P', 'EEL 4768C P', 'IDS 4941 P', 'ARH 2000 P', 'EEE 4510 P', 'COP 4610 P', 'EEL 4914C P', 'CDA 4210 P', 'EEE 4351 P', 'CEN 4010 P', 'EEL 4915C P', 'EEL 4794 P', 'ENT 2112 P', 'HUM 2022 P', 'PHI 2010 P', 'LIT 2000 P']
X = Classes[feature_cols] # Features
y = Classes[Predict_cols] # Target variable


# Create Decision Tree classifer object
clf = DecisionTreeClassifier()

# Train Decision Tree Classifer
model = clf.fit(X,y)

#Predict the response for test dataset
y_pred = model.predict(X)

# Model Accuracy, how often is the classifier correct?
print("Accuracy:",metrics.accuracy_score(y, y_pred))
